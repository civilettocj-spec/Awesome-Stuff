# Middle East Map Trainer

A free, Seterra-style geography practice website based on the uploaded **Map Quiz Study Guide**.

## Included
- Countries listed in the guide
- Capital cities listed in the guide
- Physical geography terms listed in the guide (seas, straits, gulfs, regions, mountains, desert, river, etc.)
- Istanbul, Izmir (Smyrna), Mecca, and Alexandria
- 15-minute round timer
- Click-on-the-map answers
- Score, streak, missed-answer history, and target reveal
- Quiz lengths of 10, 20, 40, or all items
- Separate modes plus a mixed mode

## Run locally
Open `index.html` in a browser with an internet connection.

The site uses:
- Leaflet for the interactive map
- OpenStreetMap tiles for the basemap
- A public GeoJSON country-boundary dataset loaded at runtime

## Free hosting
### GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Open **Settings → Pages**.
4. Choose the main branch as the publishing source.
5. GitHub Pages will give you a free `github.io` address.

### Netlify / Cloudflare Pages
Upload the folder as a static site. No server or API key is required.
